import * as React from 'react';
import {
  View,
  Text
} from 'react-native';

export class JoinGame extends React.Component {
  render() {

    return (
      <View>
        <Text>This is the JoinGame screen</Text>
      </View>
    );
  }
}

export default JoinGame