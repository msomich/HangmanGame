import * as React from 'react';
import {
  View,
  Text
} from 'react-native';

export class StartGame extends React.Component {
  render() {
    
    return (
      <View>
        <Text>This is the StartGame screen</Text>
      </View>
    )
  }
}

export default StartGame