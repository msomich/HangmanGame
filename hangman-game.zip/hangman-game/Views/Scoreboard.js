import * as React from 'react';
import {
  View,
  Text
} from 'react-native';

export class Scoreboard extends React.Component {
  render() {
    
    return (
      <View>
        <Text>This is the Scoreboard screen</Text>
      </View>
    );
  }
}

export default Scoreboard